/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controllers.Facades;

import Controllers.APIs.API;
import Controllers.APIs.APIEstudiantes;
import Controllers.Parsers.Requests.RequestEstudiante;
import Controllers.Parsers.Requests.RequestParser;
import Controllers.Parsers.Response.ResponseEstudiante;
import Controllers.Parsers.Response.ResponseNueva;
import Controllers.Parsers.Response.ResponseParser;
import Models.Estudiante;
import java.util.ArrayList;

/**
 *
 * @author DELL
 */
public class FacadeEstudiante {

    private ResponseParser<Estudiante> responseParser;
    private ResponseParser<Estudiante> getParse;
    private RequestParser<Estudiante> requestParser;
    private API<Estudiante> apiRest;

    public FacadeEstudiante(String path) {
        this.apiRest = new APIEstudiantes(path);
        this.requestParser = new RequestEstudiante();
        this.responseParser = new ResponseNueva(this.apiRest);
        this.getParse = new ResponseEstudiante(this.apiRest);
    }

    public ArrayList<Estudiante> getEstudiantes() {
        try {
            this.apiRest.GET();
        } catch (Exception e) {
            System.out.println("Error" + e.getMessage());
            return new ArrayList<Estudiante>();
        }
        return this.getParse.parseResponses();
    }
    
    public boolean postEstudiante(Estudiante estudiante){
        boolean result = false;
        this.requestParser.setObject(estudiante);
        try {
            this.apiRest.POST(this.requestParser);
            result = this.responseParser.parseSuccess();
        } catch (Exception e) {
            System.out.println("Error " + e.getMessage());
            return false;
        }
        return result;
    }
    
     public boolean deleteEstudiante(Estudiante estudiante){
        boolean result = false;
        this.requestParser.setParams(estudiante,null);
        try {
            this.apiRest.DELETE(this.requestParser);
            result = this.responseParser.parseSuccess();
        } catch (Exception e) {
            System.out.println("Error " + e.getMessage());
            return false;
        }
        return result;
    }
     
     public boolean putEstudiante(Estudiante estudiante){
         boolean result = false;
         this.requestParser.setObject(estudiante);
         this.requestParser.setParams(estudiante, null);
         try {
             this.apiRest.PUT(this.requestParser);
             result = this.responseParser.parseSuccess();
         } catch (Exception e) {
             System.out.println("Error " + e);
             return false;
         }
         return result;
         }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.grupo2.soa;

/**
 *
 * @author DELL
 */
public class Grupo2SOA {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}

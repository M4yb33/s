<?php
// Obtener el ID del post a editar
$id = $_GET['id'];

// Si el formulario fue enviado, hacer la solicitud PUT
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        'id' => $id,
        'title' => $_POST['title'],
        'body' => $_POST['body'],
        'userId' => 1
    ];

    $options = [
        'http' => [
            'method'  => 'PUT',
            'header'  => "Content-Type: application/json",
            'content' => json_encode($data)
        ]
    ];

    // Enviar los datos a la API
    $context  = stream_context_create($options);
    $result = file_get_contents("https://jsonplaceholder.typicode.com/posts/$id", false, $context);

    // Redirigir a la página principal
    header('Location: index.php');
}

// Obtener los datos actuales del post
$post = file_get_contents("https://jsonplaceholder.typicode.com/posts/$id");
$post = json_decode($post, true);
?>

<h2>✏️ Editar post</h2>
<form method="POST">
    <label>Título:</label><br>
    <input type="text" name="title" value="<?= htmlspecialchars($post['title']) ?>"><br>
    <label>Contenido:</label><br>
    <textarea name="body"><?= htmlspecialchars($post['body']) ?></textarea><br>
    <button type="submit">Actualizar</button>
</form>

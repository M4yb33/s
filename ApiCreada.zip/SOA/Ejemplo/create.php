<?php
// Si el formulario fue enviado, hacer la solicitud POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        'title' => $_POST['title'],
        'body' => $_POST['body'],
        'userId' => 1
    ];

    $options = [
        'http' => [
            'method'  => 'POST',
            'header'  => "Content-Type: application/json",
            'content' => json_encode($data)
        ]
    ];

    // Enviar los datos a la API
    $context  = stream_context_create($options);
    $result = file_get_contents('https://jsonplaceholder.typicode.com/posts', false, $context);

    // Redirigir a la página principal
    header('Location: index.php');
}
?>

<h2>➕ Crear nuevo post</h2>
<form method="POST">
    <label>Título:</label><br>
    <input type="text" name="title" required><br>
    <label>Contenido:</label><br>
    <textarea name="body" required></textarea><br>
    <button type="submit">Guardar</button>
</form>

<?php
// Obtener el ID del post a eliminar
$id = $_GET['id'];

// Configurar la solicitud DELETE
$options = [
    'http' => [
        'method'  => 'DELETE'
    ]
];

// Enviar la solicitud DELETE
$context  = stream_context_create($options);
$result = file_get_contents("https://jsonplaceholder.typicode.com/posts/$id", false, $context);

// Redirigir a la página principal
header('Location: index.php');

<?php
// Obtener todos los posts desde la API
$posts = file_get_contents('https://jsonplaceholder.typicode.com/posts');
$posts = json_decode($posts, true);
?>

<h2>📋 Lista de Posts</h2>
<a href="create.php">➕ Crear nuevo</a>
<table border="1" cellpadding="10">
    <tr>
        <th>ID</th>
        <th>Título</th>
        <th>Acciones</th>
    </tr>
    <?php foreach ($posts as $post): ?>
    <tr>
        <td><?= $post['id'] ?></td>
        <td><?= htmlspecialchars($post['title']) ?></td>
        <td>
            <a href="edit.php?id=<?= $post['id'] ?>">✏️ Editar</a> | 
            <a href="delete.php?id=<?= $post['id'] ?>" onclick="return confirm('¿Seguro de eliminar?')">🗑️ Eliminar</a>
        </td>
    </tr>
    <?php endforeach; ?>
</table>

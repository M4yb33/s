<?php
include_once __DIR__ . '/Connexion.php';
require_once __DIR__ . '/Student.php';


class StudentRepository {
    private PDO $db;

    public function __construct() {
        $this->db = Connexion::connect();
    }
    
    public function getAll(): array {
        $stmt = $this->db->query("SELECT * FROM estudiantes");
        $students = [];
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $students[] = new Student($row['cedula'], $row['nombre'], $row['apellido'], $row['direccion'], $row['telefono']);
        }
        return $students;
    }
    
    public function getByCedula(string $cedula): ?Student {
        $stmt = $this->db->prepare("SELECT * FROM estudiantes WHERE cedula = ?");
        $stmt->execute([$cedula]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row ? new Student($row['cedula'], $row['nombre'], $row['apellido'], $row['direccion'], $row['telefono']) : null;
    }
    
    public function insert(Student $student): bool {
        $stmt = $this->db->prepare("INSERT INTO students (cedula, nombre, apellido, direccion, telefono) VALUES (?, ?, ?, ?, ?)");
        return $stmt->execute([$student->cedula, $student->nombre, $student->apellido, $student->direccion, $student->telefono]);
    }
    
    public function update(Student $student): bool {
        $stmt = $this->db->prepare("UPDATE students SET nombre = ?, apellido = ?, direccion = ?, telefono = ? WHERE cedula = ?");
        return $stmt->execute([$student->nombre, $student->apellido, $student->direccion, $student->telefono, $student->cedula]);
    }
    
    public function delete(string $cedula): bool {
        $stmt = $this->db->prepare("DELETE FROM estudiantes WHERE cedula = ?");
        return $stmt->execute([$cedula]);
    }
}
?>

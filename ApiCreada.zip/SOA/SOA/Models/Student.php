<?php
class Student {
    public string $cedula;
    public string $nombre;
    public string $apellido;
    public string $direccion;
    public string $telefono;

    public function __construct(string $cedula, string $name, string $lastname, string $address, string $telephone) {
        $this->cedula = $cedula;
        $this->nombre = $name;
        $this->apellido = $lastname;
        $this->direccion = $address;
        $this->telefono = $telephone;
    }
}
?>

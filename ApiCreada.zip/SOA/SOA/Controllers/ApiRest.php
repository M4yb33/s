<?php
require_once __DIR__ . '/../Models/StudentRepository.php';

$type = $_SERVER['REQUEST_METHOD'];
$repo = new StudentRepository();

switch ($type) {
    case "GET":
        if (isset($_GET['cedula'])) {
            $cedula = $_GET['cedula'];
            $student = $repo->getByCedula($cedula);
            if ($student) {
                header('Content-Type: application/json');
                echo json_encode($student);
            } else {
                http_response_code(404);
                echo json_encode(['error' => 'Studentxamm not found']);
            }
        } else {
            $students = $repo->getAll();
            header('Content-Type: application/json');
            echo json_encode($students);
        }
        break;
    case "POST":
        $data = json_decode(file_get_contents('php://input'), true);
        if (isset($data['cedula'], $data['nombre'], $data['apellido'], $data['direccion'], $data['telephone'])) {
            $student = new Student($data['cedula'], $data['nombre'], $data['apellido'], $data['address'], $data['telephone']);
            if ($repo->insert($student)) {
                http_response_code(201);
                echo json_encode(['message' => 'Student created successfully']);
            } else {
                http_response_code(500);
                echo json_encode(['error' => 'Failed to create student']);
            }
        } else {
            http_response_code(400);
            echo json_encode(['error' => 'Invalid input dx']);
        }
        break;
    case "DELETE":
        if (isset($_GET['cedula'])){
            $cedula = $_GET['cedula'];
            if ($repo->delete($cedula)){
                http_response_code(201);
                echo json_encode(['sucess'=>'Student delete correctly']);
            }else{
                http_response_code(404);
                echo json_encode(['error'=>'Student not found']);    
            }
        }else{
            http_response_code(400);
            echo json_encode(['error'=>'Invalid Input']);    
        }
        break;
    default:
    http_response_code(400);
    echo json_encode(['error'=>'Invalid Input']);  
}
<?php
include_once "../Models/Select.php";
include_once "../Models/Insert.php";
include_once "../Models/Update.php";
include_once "../Models/Delete.php";

header('Content-Type: application/json');

$opcion = $_SERVER['REQUEST_METHOD'];

switch ($opcion) {
    case 'GET':
    if (isset($_GET['cedula'])) {
        $cedula = $_GET['cedula'];
        $resultado = crudSelect::buscarPorCedula($cedula);
        echo json_encode($resultado);
    } else {
        crudSelect::seleccionarEstudiante();
    }
    break;

    /*case 'GET':
        crudSelect::seleccionarEstudiante();
        break;*/

    case 'POST':
        $datosI = file_get_contents("php://input");
        $data = json_decode($datosI, true);
        if (!$data) {
            echo json_encode(["error" => "Datos inválidos"]);
            exit;
        }
        crudInsert::insertarEstudiante($data);
        break;

    case 'PUT':
        /* MI METODO:*/
        parse_str($_SERVER['QUERY_STRING'], $params);
        $cedula = $params['cedula'] ?? null;

        $datosU = file_get_contents("php://input");
        $data = json_decode($datosU, true);

        if (!$cedula || !$data) {
            echo json_encode(["error" => "Datos incompletos para actualización"]);
            exit;
        }

        crudUpdate::actualizarEstudiante($cedula, $data);

        // OTRA FORMA DE HACERLO:
        /*$inputData = file_get_contents("php://input");
        $data = json_decode($inputData, true);
        $cedula = $_GET['cedula'];
        $nombre = $data['nombre'];
        $apellido = $data['apellido'];
        $direccion = $data['direccion'];
        $telefono = $data['telefono'];
        crudUpdate::actualizarEstudiante($cedula, $nombre, $apellido, $direccion, $telefono);*/
        break;

    case 'DELETE':
        $cedula = $_GET['cedula'] ?? null;
        if (!$cedula) {
            echo json_encode(["error" => "Falta la cédula para eliminar"]);
            exit;
        }

        $response = crudEliminar::eliminarEstudiante($cedula);
        echo $response;
        break;
    /*$cedula = $_GET['cedula'];
    crudEliminar::eliminarEstudiante($cedula);*/

    default:
        echo json_encode(["error" => "Método no permitido"]);
        break;
}
?>
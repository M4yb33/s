<?php
require_once "Conexion.php";
class crudSelect
{
    public static function seleccionarEstudiante()
    {
        $object = new Conexion();
        $conexion = $object->conectar();
        $sqlSelect = "SELECT * FROM students";
        $result = $conexion->prepare($sqlSelect);
        $result->execute();
        $data = $result->fetchAll(PDO::FETCH_ASSOC);
        // $data = $result->fetchAll(PDO::FETCH_ASSOC) devuelve un array asociativo con los resultados de la consulta
//print_r($data);
/*$response = [
    "total" => count($data),
    "rows" => $data
];*/
        header('Content-Type: application/json');
        echo json_encode($data);

    }

    public static function buscarPorCedula($cedula)
    {
        $conexion = (new Conexion())->conectar();
        $sql = "SELECT * FROM students WHERE cedula = :cedula";
        $stmt = $conexion->prepare($sql);
        $stmt->bindParam(":cedula", $cedula, PDO::PARAM_STR);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            return [
                "success" => true,
                "data" => $stmt->fetch(PDO::FETCH_ASSOC)
            ];
        } else {
            return [
                "success" => false,
                "mensaje" => "Estudiante no encontrado"
            ];
        }
    }

}

?>
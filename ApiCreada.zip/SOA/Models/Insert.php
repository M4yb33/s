<?php
require_once "Conexion.php";

class crudInsert
{
    public static function insertarEstudiante($data = [])
    {
        try {
            $object = new Conexion();
            $conexion = $object->conectar();

            // Verificar si la cédula ya existe en la base de datos
            $sqlCheck = "SELECT COUNT(*) FROM students WHERE cedula = :cedula";
            $resultCheck = $conexion->prepare($sqlCheck);
            $resultCheck->bindParam(':cedula', $data['cedula'], PDO::PARAM_STR);
            $resultCheck->execute();
            $count = $resultCheck->fetchColumn();

            if ($count > 0) {
                // La cédula ya existe
                echo json_encode([
                    "success" => false,
                    "message" => "La cédula ya está registrada."
                ]);
                return;
            }

            // Si la cédula no existe, proceder con la inserción
            $sqlInsert = "INSERT INTO students (cedula, nombre, apellido, direccion, telefono) 
                          VALUES (:cedula, :nombre, :apellido, :direccion, :telefono)";
            $result = $conexion->prepare($sqlInsert);
            $result->execute([
                ':cedula' => $data['cedula'],
                ':nombre' => $data['nombre'],
                ':apellido' => $data['apellido'],
                ':direccion' => $data['direccion'],
                ':telefono' => $data['telefono']
            ]);

            echo json_encode([
                "success" => true,
                "message" => "Estudiante insertado correctamente"
            ]);
        } catch (PDOException $e) {
            // Manejar errores
            echo json_encode([
                "success" => false,
                "message" => $e->getMessage()
            ]);
        }
    }
}
?>
<?php
require_once "Conexion.php";
class crudEliminar
{

    public static function eliminarEstudiante($cedula)
    {
        try {
            $object = new Conexion();
            $conexion = $object->conectar();

            $sqlDelete = "DELETE FROM students WHERE cedula = :cedula";
            $result = $conexion->prepare($sqlDelete);
            $result->bindParam(':cedula', $cedula, PDO::PARAM_STR);

            if ($result->execute()) {
                if ($result->rowCount() > 0) {
                    // ✅ Éxito: estudiante eliminado
                    return json_encode([
                        "success" => true,
                        "mensaje" => "Se eliminó el estudiante correctamente"
                    ]);
                } else {
                    // ❗ No se eliminó ninguna fila (cédula no existe)
                    return json_encode([
                        "success" => false,
                        "mensaje" => "No se encontró el estudiante con la cédula proporcionada"
                    ]);
                }
            } else {
                $errorInfo = $result->errorInfo();
                error_log("Error en la consulta SQL: " . implode(", ", $errorInfo));
                return json_encode([
                    "success" => false,
                    "mensaje" => "Error al eliminar el estudiante: " . implode(", ", $errorInfo)
                ]);
            }
        } catch (Exception $e) {
            error_log("Excepción atrapada: " . $e->getMessage());
            return json_encode([
                "success" => false,
                "mensaje" => "Error del servidor: " . $e->getMessage()
            ]);
        }
    }

    /*public static function eliminarEstudiante($cedula)
    {
        try {
            $object = new Conexion();
            $conexion = $object->conectar();

            $sqlDelete = "DELETE FROM students WHERE cedula = :cedula";
            $result = $conexion->prepare($sqlDelete);
            $result->bindParam(':cedula', $cedula, PDO::PARAM_STR);

            if ($result->execute()) {
                return json_encode(["mensaje" => "Se eliminó el estudiante correctamente"]);
            } else {
                $errorInfo = $result->errorInfo();
                error_log("Error en la consulta SQL: " . implode(", ", $errorInfo));
                return json_encode(["mensaje" => "Error al eliminar el estudiante: " . implode(", ", $errorInfo)]);
            }
        } catch (Exception $e) {
            error_log("Excepción atrapada: " . $e->getMessage());
            return json_encode(["mensaje" => "Error del servidor: " . $e->getMessage()]);
        }
    }*/

}



?>
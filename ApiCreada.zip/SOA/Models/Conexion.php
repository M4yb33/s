<?php
//$servidor="localhost";

class Conexion
{
    public function conectar()
    {
        //Define: permite definir variables
        define('server', "localhost");
        define('database', 'SOA');
        define('username', 'root');
        define('password', '');
        //PDO: Obliga a mandar el tipo de caracteres a manejar en la base de datos
        //:: acceder static
        $opcion = array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8');
        try {
            $conexion = new PDO("mysql:host=" . server . ";dbname=" . database, username, password, $opcion);
            //echo "Conectado a la base de datos";
            return $conexion;
        } catch (PDOException $e) {
            die("Error de conexión: " . $e->getMessage());
        }
    }
}

?>
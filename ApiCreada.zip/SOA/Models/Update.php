<?php
require_once "Conexion.php";

class crudUpdate
{
    /*  MI METODO:   */
    public static function actualizarEstudiante($cedula, $args = [])
    {
        $object = new Conexion();
        $conexion = $object->conectar();

        // Validar parámetros
        if (!$args || !is_array($args)) {
            echo json_encode(["error" => "Datos de actualización inválidos"]);
            return;
        }

        // Preparar SQL
        $sqlUpdate = "UPDATE students SET nombre = :nombre, apellido = :apellido, 
                      direccion = :direccion, telefono = :telefono WHERE cedula = :cedula";

        try {
            $result = $conexion->prepare($sqlUpdate);
            $result->execute([
                ':cedula' => $cedula,
                ':nombre' => $args['nombre'] ?? '',
                ':apellido' => $args['apellido'] ?? '',
                ':direccion' => $args['direccion'] ?? '',
                ':telefono' => $args['telefono'] ?? ''
            ]);

            if ($result->rowCount() > 0) {
                echo json_encode([
                    "success" => true,
                    "mensaje" => "Usuario actualizado correctamente"
                ]);
            } else {
                echo json_encode([
                    "success" => false,
                    "mensaje" => "No se actualizó ningún registro. Verifica si los datos cambiaron o si la cédula existe."
                ]);
            }
        } catch (Exception $e) {
            echo json_encode([
                "success" => false,
                "mensaje" => "Error en la base de datos: " . $e->getMessage()
            ]);
        }
    }
}
?>

/// OTRA FORMA DE HACERLO:
/*public static function actualizarEstudiante($cedula, $nombre, $apellido, $direccion, $telefono) {
$object = new Conexion();
$conexion = $object->conectar();

// Preparar la consulta SQL
$sqlUpdate = "UPDATE 'students' SET 'nombre' =?, 'apellido' = ?, 'direccion' = ?, 'telefono' = ? WHERE 'cedula' = ?";
$result = $conexion->prepare($sqlUpdate);

// Vincular los parámetros
$result->bindParam(5, $cedula);
$result->bindParam(1, $nombre);
$result->bindParam(2, $apellido);
$result->bindParam(3, $direccion);
$result->bindParam(4, $telefono);

$result->execute();
$dataJS = json_encode("Se actualizó el estudiante");
print_r($dataJS);
}*/
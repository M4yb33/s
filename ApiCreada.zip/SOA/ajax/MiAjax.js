let urlApi = "../Controllers/ApiRest.php"
let isEditing = false

document.addEventListener("DOMContentLoaded", () => {
  getUser();
})

//Mi metodo para cargar los datos
function getUser() {
  $.ajax({
      url: urlApi,
      dataType: "json",
      method: "GET",
      success: (response) => {
          console.log("Datos recibidos:", response);
          if (response && response.rows) {
              $("#dg").datagrid("loadData", {
                  total: response.total,
                  rows: response.rows,
              });
          } else {
              console.error("Formato de respuesta inválido.");
          }
      },
      error: (xhr, status, error) => {
        console.error("Error al cargar los datos:", xhr.responseText);
      }
  });
}

//Mi nuevo usuario
function newUser() {
  isEditing = false
  $("#dlg").dialog("open").dialog("center").dialog("setTitle", "Nuevo Usuario")
  $("#fm").form("clear")
}


//Mi guardar usuario
function saveUser() {
  var cedula = $('input[name="cedula"]').val()
  var nombre = $('input[name="nombre"]').val()
  var apellido = $('input[name="apellido"]').val()
  var direccion = $('input[name="direccion"]').val()
  var telefono = $('input[name="telefono"]').val()

  if (!cedula || !nombre || !apellido || !direccion || !telefono) {
    let divError = document.getElementById("errorShow")
    divError.style.display = "block"

    setTimeout(() => {
      divError.style.display = "none"
    }, 1500)

    return
  }

  let form = {
    cedula: cedula,
    nombre: nombre,
    apellido: apellido,
    direccion: direccion,
    telefono: telefono,
  }

  $.ajax({
  url: isEditing ? urlApi + `/?cedula=${cedula}` : urlApi,
  type: isEditing ? "PUT" : "POST", 
  contentType: "application/json; charset=utf-8",
  data: JSON.stringify(form),
  success: (response) => {
    $("#dlg").dialog("close");
    getUser();
  },
  error: (xhr, status, error) => {
    console.log(xhr);
    let divError = document.getElementById("serverShow");
    let errorServer = document.getElementById("errorServer");
    errorServer.textContent = `${xhr?.responseJSON?.error || "Error desconocido"}`;
    divError.style.display = "block";

    setTimeout(() => {
      divError.style.display = "none";
    }, 1500);
  },
});

}

//Mi editar usuarios
function editUser() {
  var row = $("#dg").datagrid("getSelected")
  if (row) {
    isEditing = true
    $("#dlg").dialog("open").dialog("center").dialog("setTitle", "Editar Usuario")
    $("#fm").form("load", {
      cedula: row.cedula,
      nombre: row.nombre,
      apellido: row.apellido,
      direccion: row.direccion,
      telefono: row.telefono,
    })
  } else {
    $.messager.alert('Aviso', 'Por favor, selecciona un usuario para editar.', 'warning');
  }
}

//mi metodo de eliminar
function destroyUser() {
  var row = $("#dg").datagrid("getSelected");

  if (row) {
    let cedula = row.cedula; 
    console.log("Cédula enviada al servidor:", cedula);

    $.messager.confirm('Confirmar', '¿Estás seguro de que deseas eliminar este usuario?', function(r) {
      if (r) {
        $.ajax({
          url: urlApi + `/?cedula=${cedula}`,
          method: "DELETE",
          contentType: "application/json",
          success: (response) => {
            console.log("Respuesta del servidor:", response);
            getUser();
          },
          error: (xhr) => {
            console.error("Error al eliminar:", xhr.responseText);
          },
        });
      } else {
        console.log("Eliminación cancelada");
      }
    });
  } else {
    $.messager.alert('Aviso', 'Por favor, selecciona un usuario para eliminar.', 'warning');
  }
}

//-------------------------------------------------------------------------------------------------
/*
//metodo para eliminar el usuario utilizado posteriormente
function eliminarDatos(cedula){
  $.ajax({
    url: "../Controllers/ApiRest.php/?cedula=" + encodeURIComponent(cedula),
    type: "DELETE",
    DataType: "json",
    success: function (response) {
      if (response.message) {
        actualizarTabla();
      } else {
        alert("Error al eliminar el usuario: " + (response.error || "Error desconocido"));
      }
    }
  });
}

function destroyUsers() {
  if (url == 'edit') {
    actualizarTabla();
  } else {
    guardarDatos();
  }
}

function actualizarTabla() {
  alert("Operación exitosa. Actualizando tabla");
  $('#dlg').dialog('close');

  $.ajax({
    url: "../Controllers/ApiRest.php",
    type: "GET",
    DataType: "json",
    success: function (data){
      $('#dg').datagrid('loadData', data);
    }
  });

}

function guardarDatos() {
  alert("Operación exitosa. Guardando datos");

  $.ajax({
    url: "../Controllers/ApiRest.php",
    type: "POST",
    DataType: "json",
    data: $('#fm').serialize(),
    success: function (data) {
      $('#dg').datagrid('loadData', data);
    }
  });
}

//Update método a manejar de momento

function updateUser() {
 const formData = {
  cedula: $('input[name="cedula"]').val(),
  nombre: $('input[name="nombre"]').val(),
  apellido: $('input[name="apellido"]').val(),
  direccion: $('input[name="direccion"]').val(),
  telefono: $('input[name="telefono"]').val(),
 };

 $.ajax({
  url: "../Controllers/ApiRest.php",
  method: "PUT",
  contentType: "application/json",
  data: JSON.stringify(formData),
  success: function () {
    cargarDatos();
    $("#fm")[0].reset();
    $("#dlg").dialog("close");
    getUser();
  },
  error: function () {
    console.error("Error hubo un problema al actualizar el usuario.");
  },
 })
}*/
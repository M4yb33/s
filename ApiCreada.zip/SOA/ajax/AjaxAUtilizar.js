let urlApi = "../Controllers/ApiRest.php"
let isEditing = false

document.addEventListener("DOMContentLoaded", () => {
  getUser();
})

//-------------------------------------------------------------------------------------------------

//metodo para eliminar el usuario utilizado posteriormente
function eliminarDatos(cedula){
  $.ajax({
    url: "../Controllers/ApiRest.php/?cedula=" + encodeURIComponent(cedula),
    type: "DELETE",
    DataType: "json",
    success: function (response) {
      if (response.message) {
        actualizarTabla();
      } else {
        alert("Error al eliminar el usuario: " + (response.error || "Error desconocido"));
      }
    }
  });
}

function destroyUsers() {
  if (url == 'edit') {
    actualizarTabla();
  } else {
    guardarDatos();
  }
}

function actualizarTabla() {
  alert("Operación exitosa. Actualizando tabla");
  $('#dlg').dialog('close');

  $.ajax({
    url: "../Controllers/ApiRest.php",
    type: "GET",
    DataType: "json",
    success: function (data){
      $('#dg').datagrid('loadData', data);
    }
  });

}

function guardarDatos() {
  alert("Operación exitosa. Guardando datos");

  $.ajax({
    url: "../Controllers/ApiRest.php",
    type: "POST",
    DataType: "json",
    data: $('#fm').serialize(),
    success: function (data) {
      $('#dg').datagrid('loadData', data);
    }
  });
}

//Update método a manejar de momento

function updateUser() {
 const formData = {
  cedula: $('input[name="cedula"]').val(),
  nombre: $('input[name="nombre"]').val(),
  apellido: $('input[name="apellido"]').val(),
  direccion: $('input[name="direccion"]').val(),
  telefono: $('input[name="telefono"]').val(),
 };

 $.ajax({
  url: "../Controllers/ApiRest.php",
  method: "PUT",
  contentType: "application/json",
  data: JSON.stringify(formData),
  success: function () {
    cargarDatos();
    $("#fm")[0].reset();
    $("#dlg").dialog("close");
    getUser();
  },
  error: function () {
    console.error("Error hubo un problema al actualizar el usuario.");
  },
 })
}

function editUser() {
    var row = $('#dg').datagrid('getSelected');
    if (row) {
        $('#dlg').dialog('open').dialog('setTitle', 'Editar Usuario');
        $('#fm').form('load', row);
        url = 'update';
        isNewUser = false;
    }
}
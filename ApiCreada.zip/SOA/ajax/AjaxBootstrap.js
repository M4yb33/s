let urlApi = "../Controllers/ApiRest.php";
let isEditing = false;
let selectedCedula = null;
let currentPage = 1;
let pageSize = 5;
let usersData = []; 

document.addEventListener("DOMContentLoaded", function () {
  getUser();
});

function getUser() {
  $.ajax({
    url: urlApi,
    type: "GET",
    dataType: "json",
    success: function (response) {
      if (response.rows && Array.isArray(response.rows)) {
        usersData = response.rows; 
        renderTable(); 
      } else {
        console.warn("La respuesta del servidor no tiene una propiedad 'rows'.");
      }
    },
    error: function (xhr, status, error) {
      console.error("Error al cargar los usuarios:", error);
    },
  });
}

function renderTable() {
  let startIndex = (currentPage - 1) * pageSize;
  let endIndex = startIndex + pageSize;
  let currentPageUsers = usersData.slice(startIndex, endIndex);

  let tabla = document.getElementById("tablaUsuarios");
  tabla.innerHTML = ""; 

  currentPageUsers.forEach((usuario) => {
    let fila = `
      <tr>
        <td>${usuario.cedula}</td>
        <td>${usuario.nombre}</td>
        <td>${usuario.apellido}</td>
        <td>${usuario.direccion}</td>
        <td>${usuario.telefono}</td>
        <td>
          <button class="btn btn-sm btn-warning me-1" onclick='editUser(${JSON.stringify(usuario)})'>Editar</button>
          <button class="btn btn-sm btn-danger" onclick='destroyUser("${usuario.cedula}")'>Eliminar</button>
        </td>
      </tr>`;
    tabla.innerHTML += fila;
  });

  document.getElementById("prevPageBtn").classList.toggle("disabled", currentPage === 1);
  document.getElementById("nextPageBtn").classList.toggle("disabled", currentPage * pageSize >= usersData.length);
}

function changePage(direction) {
  if (direction === 'next' && currentPage * pageSize < usersData.length) {
    currentPage++;
  } else if (direction === 'prev' && currentPage > 1) {
    currentPage--;
  }
  renderTable(); 
}

function newUser() {
  isEditing = false;
  selectedCedula = null;
  $("#modalUserLabel").text("Nuevo Usuario");
  $("#fm")[0].reset();
  new bootstrap.Modal(document.getElementById("modalUser")).show();
}

function saveUser() {
  let cedula = $('input[name="cedula"]').val().trim();
  let nombre = $('input[name="nombre"]').val().trim();
  let apellido = $('input[name="apellido"]').val().trim();
  let direccion = $('input[name="direccion"]').val().trim();
  let telefono = $('input[name="telefono"]').val().trim();

  if (!cedula || !nombre || !apellido || !direccion || !telefono) {
    showError("Todos los campos son obligatorios.");
    return;
  }

  let form = { cedula, nombre, apellido, direccion, telefono };

  $.ajax({
    url: isEditing ? `${urlApi}/?cedula=${selectedCedula}` : urlApi,
    type: isEditing ? "PUT" : "POST",
    contentType: "application/json",
    data: JSON.stringify(form),
    success: () => {
      bootstrap.Modal.getInstance(document.getElementById("modalUser")).hide();
      getUser(); 
    },
    error: (xhr) => {
      showServerError(xhr?.responseJSON?.error || "Error desconocido.");
    },
  });
}

function editUser(row) {
  isEditing = true;
  selectedCedula = row.cedula;
  $("#modalUserLabel").text("Editar Usuario");

  $('input[name="cedula"]').val(row.cedula);
  $('input[name="nombre"]').val(row.nombre);
  $('input[name="apellido"]').val(row.apellido);
  $('input[name="direccion"]').val(row.direccion);
  $('input[name="telefono"]').val(row.telefono);

  new bootstrap.Modal(document.getElementById("modalUser")).show();
}

function destroyUser(cedula) {
  if (confirm("¿Estás seguro de que deseas eliminar este usuario?")) {
    $.ajax({
      url: `${urlApi}/?cedula=${cedula}`,
      method: "DELETE",
      success: () => {
        getUser(); 
      },
      error: (xhr) => {
        showServerError("Error al eliminar: " + xhr.responseText);
      },
    });
  }
}

function showError(message) {
  let divError = document.getElementById("errorShow");
  document.getElementById("errorMessage").textContent = message;
  divError.classList.remove("d-none");

  setTimeout(() => {
    divError.classList.add("d-none");
  }, 2000);
}

function showServerError(message) {
  let divError = document.getElementById("serverShow");
  document.getElementById("errorServer").textContent = message;
  divError.classList.remove("d-none");

  setTimeout(() => {
    divError.classList.add("d-none");
  }, 2000);
}

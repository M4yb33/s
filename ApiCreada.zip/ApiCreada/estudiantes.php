<?php
require 'conexion.php';
header("Content-Type: application/json");

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $stmt = $conn->query("SELECT * FROM estudiantes");
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
}

if ($method === 'POST') {
    $input = json_decode(file_get_contents("php://input"), true);
    $nombre = $input['nombre'];

    $stmt = $conn->prepare("INSERT INTO estudiantes (nombre) VALUES (?)");
    $stmt->execute([$nombre]);

    echo json_encode(["mensaje" => "Estudiante creado"]);
}
?>

<?php
require 'conexion.php';
header("Content-Type: application/json");

$method = $_SERVER['REQUEST_METHOD'];

// Inscribir estudiante
if ($method === 'POST') {
    $input = json_decode(file_get_contents("php://input"), true);
    $estudiante_id = $input['estudiante_id'];
    $curso_id = $input['curso_id'];
    $stmt = $conn->prepare("INSERT INTO inscripciones (estudiante_id, curso_id) VALUES (?, ?)");
    $stmt->execute([$estudiante_id, $curso_id]);
    echo json_encode(["mensaje" => "Estudiante inscrito"]);
}

// Estudiantes en un curso
if ($method === 'GET' && isset($_GET['curso_id'])) {
    $curso_id = $_GET['curso_id'];
    $stmt = $conn->prepare("
        SELECT e.id, e.nombre
        FROM estudiantes e
        JOIN inscripciones i ON e.id = i.estudiante_id
        WHERE i.curso_id = ?
    ");
    $stmt->execute([$curso_id]);
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
}

// Cursos en los que está un estudiante
if ($method === 'GET' && isset($_GET['estudiante_id'])) {
    $estudiante_id = $_GET['estudiante_id'];
    $stmt = $conn->prepare("
        SELECT c.id, c.nombre
        FROM cursos c
        JOIN inscripciones i ON c.id = i.curso_id
        WHERE i.estudiante_id = ?
    ");
    $stmt->execute([$estudiante_id]);
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
}
?>

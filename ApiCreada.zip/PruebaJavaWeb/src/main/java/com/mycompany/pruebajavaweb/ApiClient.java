/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.pruebajavaweb;

import com.google.gson.Gson;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Arrays;
import java.util.List;

/**
 *
 * @author DELL
 */
public class ApiClient {
    private final Gson gson = new Gson();
    private final String BASE_URL = "http://localhost/ApiCreada/";

    public List<Curso> getCursos() throws IOException {
        URL url = new URL(BASE_URL + "cursos.php");
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        con.setRequestMethod("GET");

        try (BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream()))) {
            Curso[] cursos = gson.fromJson(br, Curso[].class);
            return Arrays.asList(cursos);
        }
    }

    public void crearCurso(String nombre) throws IOException {
        Curso curso = new Curso(nombre);
        enviarJson("cursos.php", gson.toJson(curso));
    }

    public List<Estudiante> getEstudiantes() throws IOException {
        URL url = new URL(BASE_URL + "estudiantes.php");
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        con.setRequestMethod("GET");

        try (BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream()))) {
            Estudiante[] ests = gson.fromJson(br, Estudiante[].class);
            return Arrays.asList(ests);
        }
    }

    public void crearEstudiante(String nombre) throws IOException {
        Estudiante est = new Estudiante(nombre);
        enviarJson("estudiantes.php", gson.toJson(est));
    }

    public void inscribir(int estudiante_id, int curso_id) throws IOException {
        String json = String.format("{\"estudiante_id\":%d,\"curso_id\":%d}", estudiante_id, curso_id);
        enviarJson("inscripciones.php", json);
    }

    public List<Estudiante> getEstudiantesPorCurso(int curso_id) throws IOException {
        URL url = new URL(BASE_URL + "inscripciones.php?curso_id=" + curso_id);
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        con.setRequestMethod("GET");

        try (BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream()))) {
            Estudiante[] ests = gson.fromJson(br, Estudiante[].class);
            return Arrays.asList(ests);
        }
    }

    private void enviarJson(String endpoint, String json) throws IOException {
        URL url = new URL(BASE_URL + endpoint);
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        con.setRequestMethod("POST");
        con.setRequestProperty("Content-Type", "application/json");
        con.setDoOutput(true);

        try (OutputStream os = con.getOutputStream()) {
            os.write(json.getBytes());
        }

        con.getInputStream().close(); // para confirmar que se envió
    }
    
    public List<Curso> getCursosPorEstudiante(int estudiante_id) throws IOException {
    URL url = new URL(BASE_URL + "inscripciones.php?estudiante_id=" + estudiante_id);
    HttpURLConnection con = (HttpURLConnection) url.openConnection();
    con.setRequestMethod("GET");

    try (BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream()))) {
        Curso[] cursos = gson.fromJson(br, Curso[].class);
        return Arrays.asList(cursos);
    }
}

}

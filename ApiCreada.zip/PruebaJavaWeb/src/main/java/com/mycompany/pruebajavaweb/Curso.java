/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.pruebajavaweb;

/**
 *
 * @author DELL
 */
public class Curso {
    public int id;
    public String nombre;

    public Curso(String nombre) {
        this.nombre = nombre;
    }

    public String toString() {
        return nombre + " (ID: " + id + ")";
    }
}

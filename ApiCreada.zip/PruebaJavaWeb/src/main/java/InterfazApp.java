import com.mycompany.pruebajavaweb.ApiClient;
import com.mycompany.pruebajavaweb.Curso;
import com.mycompany.pruebajavaweb.Estudiante;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

public class InterfazApp {
    private static final ApiClient api = new ApiClient();

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Gestión de Cursos y Estudiantes");
            frame.setSize(700, 500);
            frame.setLayout(null);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            // Crear curso
            JLabel lblCurso = new JLabel("Nombre del curso:");
            lblCurso.setBounds(30, 20, 150, 25);
            JTextField txtCurso = new JTextField();
            txtCurso.setBounds(180, 20, 200, 25);
            JButton btnCurso = new JButton("Crear Curso");
            btnCurso.setBounds(400, 20, 150, 25);

            // Crear estudiante
            JLabel lblEst = new JLabel("Nombre del estudiante:");
            lblEst.setBounds(30, 60, 150, 25);
            JTextField txtEst = new JTextField();
            txtEst.setBounds(180, 60, 200, 25);
            JButton btnEst = new JButton("Crear Estudiante");
            btnEst.setBounds(400, 60, 150, 25);

            // ComboBox para cursos y estudiantes
            JLabel lblCursoSel = new JLabel("Seleccionar curso:");
            lblCursoSel.setBounds(30, 110, 150, 25);
            JComboBox<Curso> boxCursos = new JComboBox<>();
            boxCursos.setBounds(180, 110, 200, 25);

            JLabel lblEstSel = new JLabel("Seleccionar estudiante:");
            lblEstSel.setBounds(30, 150, 150, 25);
            JComboBox<Estudiante> boxEsts = new JComboBox<>();
            boxEsts.setBounds(180, 150, 200, 25);

            JButton btnInsc = new JButton("Inscribir");
            btnInsc.setBounds(400, 150, 150, 25);

            // Área de resultados
            JTextArea resultArea = new JTextArea();
            resultArea.setEditable(false);
            JScrollPane scroll = new JScrollPane(resultArea);
            scroll.setBounds(30, 200, 620, 200);

            JButton btnVerEsts = new JButton("Ver estudiantes por curso");
            btnVerEsts.setBounds(30, 420, 250, 25);

            JButton btnVerCursos = new JButton("Ver cursos por estudiante");
            btnVerCursos.setBounds(300, 420, 250, 25);

            // Añadir componentes
            frame.add(lblCurso); frame.add(txtCurso); frame.add(btnCurso);
            frame.add(lblEst); frame.add(txtEst); frame.add(btnEst);
            frame.add(lblCursoSel); frame.add(boxCursos);
            frame.add(lblEstSel); frame.add(boxEsts); frame.add(btnInsc);
            frame.add(scroll); frame.add(btnVerEsts); frame.add(btnVerCursos);

            // Acción: crear curso
            btnCurso.addActionListener(e -> {
                String nombre = txtCurso.getText().trim();
                if (!nombre.isEmpty()) {
                    try {
                        api.crearCurso(nombre);
                        actualizarCursos(boxCursos);
                        JOptionPane.showMessageDialog(frame, "Curso creado.");
                        txtCurso.setText("");
                    } catch (Exception ex) {
                        ex.printStackTrace();
                        JOptionPane.showMessageDialog(frame, "Error al crear curso.");
                    }
                }
            });

            // Acción: crear estudiante
            btnEst.addActionListener(e -> {
                String nombre = txtEst.getText().trim();
                if (!nombre.isEmpty()) {
                    try {
                        api.crearEstudiante(nombre);
                        actualizarEstudiantes(boxEsts);
                        JOptionPane.showMessageDialog(frame, "Estudiante creado.");
                        txtEst.setText("");
                    } catch (Exception ex) {
                        ex.printStackTrace();
                        JOptionPane.showMessageDialog(frame, "Error al crear estudiante.");
                    }
                }
            });

            // Acción: inscribir estudiante
            btnInsc.addActionListener(e -> {
                Curso curso = (Curso) boxCursos.getSelectedItem();
                Estudiante est = (Estudiante) boxEsts.getSelectedItem();
                if (curso != null && est != null) {
                    try {
                        api.inscribir(est.id, curso.id);
                        JOptionPane.showMessageDialog(frame, "Estudiante inscrito.");
                    } catch (Exception ex) {
                        ex.printStackTrace();
                        JOptionPane.showMessageDialog(frame, "Error al inscribir.");
                    }
                }
            });

            // Acción: ver estudiantes por curso
            btnVerEsts.addActionListener(e -> {
                Curso curso = (Curso) boxCursos.getSelectedItem();
                if (curso != null) {
                    try {
                        List<Estudiante> ests = api.getEstudiantesPorCurso(curso.id);
                        StringBuilder sb = new StringBuilder("Estudiantes en el curso '" + curso.nombre + "':\n\n");
                        if (ests != null && !ests.isEmpty()) {
                            for (Estudiante est : ests) {
                                sb.append("- ").append(est.nombre).append("\n");
                            }
                        } else {
                            sb.append("No hay estudiantes inscritos.");
                        }
                        resultArea.setText(sb.toString());
                    } catch (Exception ex) {
                        ex.printStackTrace();
                        resultArea.setText("Error al obtener estudiantes.");
                    }
                }
            });

            // Acción: ver cursos por estudiante
            btnVerCursos.addActionListener(e -> {
                Estudiante estudiante = (Estudiante) boxEsts.getSelectedItem();
                if (estudiante != null) {
                    try {
                        List<Curso> cursos = api.getCursosPorEstudiante(estudiante.id);
                        StringBuilder sb = new StringBuilder("Cursos del estudiante '" + estudiante.nombre + "':\n\n");
                        if (cursos != null && !cursos.isEmpty()) {
                            for (Curso curso : cursos) {
                                sb.append("- ").append(curso.nombre).append("\n");
                            }
                        } else {
                            sb.append("Este estudiante no está inscrito en ningún curso.");
                        }
                        resultArea.setText(sb.toString());
                    } catch (Exception ex) {
                        ex.printStackTrace();
                        resultArea.setText("Error al obtener cursos.");
                    }
                }
            });

            // Cargar datos al iniciar
            try {
                actualizarCursos(boxCursos);
                actualizarEstudiantes(boxEsts);
            } catch (Exception ex) {
                ex.printStackTrace();
            }

            frame.setVisible(true);
        });
    }

    private static void actualizarCursos(JComboBox<Curso> box) throws Exception {
        box.removeAllItems();
        for (Curso c : api.getCursos()) {
            box.addItem(c);
        }
    }

    private static void actualizarEstudiantes(JComboBox<Estudiante> box) throws Exception {
        box.removeAllItems();
        for (Estudiante e : api.getEstudiantes()) {
            box.addItem(e);
        }
    }
}

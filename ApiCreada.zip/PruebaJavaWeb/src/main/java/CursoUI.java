
import com.google.gson.Gson;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author DELL
 */
public class CursoUI {

   private static final String API_URL = "http://localhost/ApiCreada/cursos.php";

    public static void main(String[] args) {
        JFrame frame = new JFrame("Gestión de Cursos");
        frame.setSize(400, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);

        JLabel label = new JLabel("Nombre del curso:");
        label.setBounds(30, 30, 120, 25);
        JTextField campo = new JTextField();
        campo.setBounds(160, 30, 200, 25);
        JButton boton = new JButton("Crear Curso");
        boton.setBounds(130, 80, 120, 30);

        frame.add(label);
        frame.add(campo);
        frame.add(boton);

        boton.addActionListener(e -> {
            String nombre = campo.getText();
            if (!nombre.isEmpty()) {
                try {
                    crearCurso(nombre);
                    JOptionPane.showMessageDialog(frame, "Curso creado.");
                } catch (Exception ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(frame, "Error al crear curso.");
                }
            }
        });

        frame.setVisible(true);
    }

    public static void crearCurso(String nombre) throws IOException {
        Curso curso = new Curso(nombre);
        Gson gson = new Gson();
        String json = gson.toJson(curso);

        URL url = new URL(API_URL);
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        con.setRequestMethod("POST");
        con.setDoOutput(true);
        con.setRequestProperty("Content-Type", "application/json");

        try (OutputStream os = con.getOutputStream()) {
            byte[] input = json.getBytes("utf-8");
            os.write(input, 0, input.length);
        }

        int responseCode = con.getResponseCode();
        System.out.println("Código de respuesta: " + responseCode);

        try (BufferedReader br = new BufferedReader(
                new InputStreamReader(con.getInputStream(), "utf-8"))) {
            StringBuilder response = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
                response.append(line.trim());
            }
            System.out.println("Respuesta: " + response.toString());
        }
    }

    // Clase interna Curso
    static class Curso {
        String nombre;
        public Curso(String nombre) {
            this.nombre = nombre;
        }
    }
}